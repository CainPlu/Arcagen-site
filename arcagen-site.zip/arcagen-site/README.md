# Arcagen Audit Site

## Project Structure
```
arcagen-site/
└── index.html   ← The entire site, self-contained. No backend needed.
```

## Deployment (Vercel — free, 5 minutes)

1. Go to github.com → New repo → name it `arcagen-site`
2. Upload `index.html`
3. Go to vercel.com → Add New Project → import the repo → Deploy
4. Go to Settings → Domains → add `arcagen.ai`
5. Copy the DNS records Vercel gives you into your domain registrar

Done. No API keys. No backend. No environment variables.
